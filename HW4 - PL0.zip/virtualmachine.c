#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_STACK_HEIGHT  2000
#define MAX_CODE_LENGTH  500
#define MAX_LEXI_LEVELS  3

typedef struct {

	int op;
	int l;
	int m;

} instruction;

char *getOpcode (int op);
char *getOperationcode (int op);
void execute(instruction *IR, int *PC, int *SP, int *BP, int *halt, int *lexiLevel, int *lexi, int *stack);
int base(int l, int base, int *stack);
char *printStack(int *stack, int BP, int SP, int *lexi);




int main() {

	int i, numInstruction, numBuffer;
	int lexi[MAX_LEXI_LEVELS - 1];
	int lexiLevel = 0;


	// initialization of the registers
	int SP = 0;
	int BP = 1;
	int PC = 0;
	int halt = 0;
	instruction *IR = 0;
	instruction code[MAX_CODE_LENGTH];

	//initialization of the stack
	int stack[MAX_STACK_HEIGHT];
	memset(stack, 0, MAX_STACK_HEIGHT* sizeof(int));

	//loading the input file
	FILE *ifp = fopen("mcode.txt", "r");
	FILE *ifp2 = fopen("stacktrace.txt", "w");

	numInstruction = 0;

    while (!feof(ifp) && numInstruction != MAX_CODE_LENGTH)
    {
        fscanf(ifp, " %d", &numBuffer);
        code[numInstruction].op = numBuffer;
        fscanf(ifp, " %d", &numBuffer);
        code[numInstruction].l = numBuffer;
        fscanf(ifp, " %d", &numBuffer);
        code[numInstruction].m = numBuffer;
        numInstruction++;
    }

    //Printing the input from mcode.txt
    //Fetch Cycle
    fprintf(ifp2, "Line\tOP\tL\tM\n");
    for( i = 0; i < numInstruction -1 ; i++){

        if(code[i].op != 2){
            fprintf(ifp2, "%d\t%s\t%d\t%d\n", i, getOpcode(code[i].op),
                    code[i].l, code[i].m);
        }
        else{
            fprintf(ifp2, "%d\t%s\t%d\t%s\n", i, getOpcode(code[i].op),
                    code[i].l, getOperationcode(code[i].m));
        }

    }

    //Printing initial values

    fprintf(ifp2,"\t\t\t\tPC\tBP\tSP\tstack\n");
    fprintf(ifp2, "Initial values\t\t%d\t%d\t%d\n", PC, BP, SP);

    //Fetch and Execute Cycle
    while(halt == 0){
        //Fetch Cycle
        IR = &code[PC];
        int prevPC = PC;
        PC = PC + 1;

        //Execute Cycle
        execute(IR, &PC, &SP, &BP, &halt, &lexiLevel, lexi, stack);
        fprintf(ifp2, "%d\t%s\t%d\t%d\t%d\t%d\t%d\t%s\n", prevPC, getOpcode(IR->op), IR->l,
                IR->m, PC, BP, SP, printStack(stack, BP, SP, lexi));
    }

    fprintf(ifp2, "Successfully Halted.");

    //Closing the files.
    fclose(ifp);
    fclose(ifp2);



    return 0;

}

//This is a code from the HW1 pdf -Appendix D
int base(int l, int base, int *stack){


    int b1; //find base L levels down
    b1 = base;

    while (l > 0){
        b1 = stack[b1 + 1];
        l--;
    }

    return b1;
}


//Function to convert the op to the operation
char *getOpcode (int op){
    char *opName = "";

    switch(op){
        case 1:
            opName = "LIT";
            break;
        case 2:
            opName = "OPR";
            break;
        case 3:
            opName = "LOD";
            break;
        case 4:
            opName = "STO";
            break;
        case 5:
            opName = "CAL";
            break;
        case 6:
            opName = "INC";
            break;
        case 7:
            opName = "JMP";
            break;
        case 8:
            opName = "JPC";
            break;
        case 9:
            opName = "SIO";
            break;
        case 10:
            opName = "SIO";
            break;
        case 11:
            opName = "SIO";
            break;

    }

    return opName;

}

//Function to convert the m to the operation when op = 2
char *getOperationcode (int op){
    char *opName = "";

    switch(op){
        case 0:
            opName = "0 (RET)";
            break;
        case 1:
            opName = "1 (NEG)";
            break;
        case 2:
            opName = "2 (ADD)";
            break;
        case 3:
            opName = "3 (SUB)";
            break;
        case 4:
            opName = "4 (MUL)";
            break;
        case 5:
            opName = "5 (DIV)";
            break;
        case 6:
            opName = "6 (ODD)";
            break;
        case 7:
            opName = "7 (MOD)";
            break;
        case 8:
            opName = "8 (EQL)";
            break;
        case 9:
            opName = "9 (NEQ)";
            break;
        case 10:
            opName = "10 (LSS)";
            break;
        case 11:
            opName = "11 (LEQ)";
            break;
        case 12:
            opName = "12 (GTR)";
            break;
        case 13:
            opName = "13 (GEQ)";
            break;

    }

    return opName;

}

char *printStack(int *stack, int BP, int SP, int *lexi){

    //used calloc instead of malloc to make sure that every element is 0.
    char * stringBuffer = calloc(MAX_STACK_HEIGHT, sizeof(char));

    int i = 1, j = 0;

    while (i <= SP){

        sprintf(stringBuffer+strlen(stringBuffer), "%d ", stack[i]);

        if(lexi[j] != 0 && i == lexi[j] && SP > lexi[j]){
            sprintf(stringBuffer+strlen(stringBuffer), "| ");

            if(j <2)
                j++;
        }

        i++;

    }

    return stringBuffer;


}


void execute(instruction *IR, int *PC, int *SP, int *BP, int *halt, int *lexiLevel, int *lexi, int *stack){

    int buffer = 0;

    switch(IR->op){
        case 1: //LIT
            *SP = *SP + 1;
            stack[*SP]= IR->m;
            break;
        case 2: //OPR
            switch(IR->m){
                case 0: //RET
                    *SP = *BP - 1;
                    *PC = stack[*SP + 4];
                    *BP = stack[*SP + 3];
                    break;
                case 1: //NEG
                    stack[*SP] = stack[*SP] * -1;
                    break;
                case 2: //ADD
                    *SP = *SP - 1;
                    buffer = stack[*SP] + stack[*SP + 1];
                    stack[*SP] = buffer;
                    break;
                case 3: //SUB
                    *SP = *SP - 1;
                    buffer = stack[*SP] - stack[*SP + 1];
                    stack[*SP] = buffer;
                    break;
                case 4: //MULT
                    *SP = *SP - 1;
                    buffer = stack[*SP] * stack[*SP + 1];
                    stack[*SP] = buffer;
                    break;
                case 5: //DIV
                    *SP = *SP - 1;
                    buffer = stack[*SP] / stack[*SP + 1];
                    stack[*SP] = buffer;
                    break;
                case 6: // ODD
                    stack[*SP] = stack[*SP] % 2;
                    break;
                case 7: // MOD
                    *SP = *SP - 1;
                    buffer = stack[*SP] % stack[*SP + 1];
                    stack[*SP] = buffer;
                    break;
                case 8: //EQL
                    *SP = *SP - 1;
                    buffer = stack[*SP] == stack[*SP + 1];
                    stack[*SP] = buffer;
                    break;
                case 9: //NEQ
                    *SP = *SP - 1;
                    buffer = stack[*SP] != stack[*SP + 1];
                    stack[*SP] = buffer;
                    break;
                case 10://LSS
                     *SP = *SP - 1;
                    buffer = stack[*SP] < stack[*SP + 1];
                    stack[*SP] = buffer;
                    break;
                case 11://LEQ
                     *SP = *SP - 1;
                    buffer = stack[*SP] <= stack[*SP + 1];
                    stack[*SP] = buffer;
                    break;
                case 12://GTR
                     *SP = *SP - 1;
                    buffer = stack[*SP] > stack[*SP + 1];
                    stack[*SP] = buffer;
                    break;
                case 13://GEQ
                     *SP = *SP - 1;
                    buffer = stack[*SP] >= stack[*SP + 1];
                    stack[*SP] = buffer;
                    break;
                    }

            break;
        case 3: //LOD
            *SP = *SP +1;
            stack[*SP] = stack[base(IR->l,*BP, stack) + IR->m];
            break;
        case 4: //STO
            stack[base(IR->l, *BP, stack)+ IR->m] = stack[*SP];
            *SP = *SP -1;
            break;
        case 5: //CAL
            lexi[*lexiLevel] = *SP;
            stack[*SP + 1] = 0;
            stack[*SP + 2] = base(IR->l, *BP, stack);
            stack[*SP + 3] = *BP;
            stack[*SP + 4] = *PC;
            *BP = *SP + 1;
            *PC = IR->m;
            *lexiLevel = *lexiLevel + 1;
            break;
        case 6: //INC
            *SP = *SP + IR->m;
            break;
        case 7: //JMP
            *PC = IR->m;
            break;
        case 8: //JPC
            if (stack[*SP] == 0)
                *PC = IR->m;
            *SP = *SP - 1;
            break;
        case 9: //SIO print
            printf("%d\n", stack[*SP]);
            *SP = *SP - 1;
            break;
        case 10: //SIO read
            *SP = *SP + 1;
            scanf("%d", &stack[*SP]);
            break;
        case 11: //SIO Halt
            *halt = 1;
            *PC = 0;
            *SP = 0;
            *BP = 0;
            break;

    }

}





