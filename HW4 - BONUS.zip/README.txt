
Program assemblied with provided Makefile.

6 different commands

"make" just compile the program

"make lex" compile and run the lexer

"make parse" compile, run lexer, and run parser

"make parseL" compile, run lexer, and run parser with -l command to show lexemelist.txt

"make compile" compile, run lexer, run parser, and run code

"make compileL" compile, run lexer, run parser with -l command to show lexemelist.txt, and run code
