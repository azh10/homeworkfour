//Harold Marcial - ha584124
//COP3402 - Summer 2016
//Program #2 - Lexical Scanner

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#define MAX_STR_LENGTH 11
#define MAX_DIGITS 5

typedef enum{
    nulsym = 1,
    identsym,
    numbersym,
    plussym,
    minussym,
    multsym,
    slashsym,
    oddsym,
    equalsym,
    neqsym,
    lessym,
    leqsym,
    gtrsym,
    geqsym,
    lparentsym,
    rparentsym,
    commasym,
    semicolonsym,
    periodsym,
    becomesym,
    beginsym,
    endsym,
    ifsym,
    thensym,
    whilesym,
    dosym,
    callsym,
    constsym,
    varsym,
    procsym,
    writesym,
    readsym,
    elsesym
} token_type;


typedef struct token{

    //Token Name
    char lexeme[MAX_STR_LENGTH + 1];

    //Constant
    int value;

    //Type
    token_type type;

    struct token* next;


}token;

void lexScan(char* cleanInput, token *rootToken);
token_type getReserve(char * lexeme);
void addToLinkList(token **rootToken, char *lexeme, int value, int type);
void printTableList(token *rootToken, char* tableOutput, char* listOutput);



int main(){

    char ch;


    token *rootToken = malloc(sizeof(token)); // The address of the root token.


    //Clean up of the input file
    FILE *ifp = fopen("input.txt", "r");
    FILE *ifp2 = fopen("cleaninput.txt", "w");

    //Reading the file & removing the comments

    while(!feof(ifp)) {
         ch = getc(ifp);

        if(ch == '/') {
            ch = getc(ifp);
            if (ch == '*') {
                // Encountered a /* so this is the start of the comment
                while(!feof(ifp)) {
                    ch = getc(ifp);

                    // Encountered the end of the comment.
                    if (ch == '*') {
                        ch = getc(ifp);
                        if (ch == '/') {
                            break;
                        }
                    }
                }
            } else {
                //This is a case when we encounter a /.
                fputc('/', ifp2);
                fputc(ch, ifp2);
            }
        } else {
            // Write ch to file
            if (!feof(ifp)) {
                fputc(ch, ifp2);
            }
        }
    }

    // Close files
    fclose(ifp);
    fclose(ifp2);



    lexScan("cleaninput.txt", rootToken);


    if(rootToken->next != NULL){
        printTableList(rootToken, "lexemetable.txt", "lexemelist.txt");
    }




    return 0;

}




void lexScan(char *cleaninput, token *rootToken){

    FILE *ifp = fopen("cleaninput.txt", "r");

    char ch;
    char lexeme[MAX_STR_LENGTH+1];
    token_type tokenType;
    int strCount, digCount, digBuffer;

    while(!feof(ifp)){


        ch = fgetc(ifp);

        //clearing the lexeme
        memset(lexeme, '\0', 12);

        if(isalpha(ch)){
            strCount = 0;

            while(!feof(ifp)&& (isalpha(ch) || isdigit(ch))){



                //This is pushing the ch to the string array
                lexeme[strlen(lexeme)] = ch;
                lexeme[strlen(lexeme) + 1] = '\0';
                strCount++;

                //Error check for str length
                if(strCount > MAX_STR_LENGTH){
                    printf("ERROR! Identifiers can't have more than 11 characters!");
                    exit(0);
                }


                ch = getc(ifp);

            }




            //test print
            //printf("identsym: %s\n", lexeme);


            tokenType = getReserve(lexeme);

            addToLinkList(&rootToken, lexeme,0, tokenType);

            //This is to go back 1 step because the loop went to the next ch
            ungetc(ch, ifp);
        }

        //if not a identsym
        else{
            ungetc(ch, ifp);
        }


        ch = getc(ifp);

        if(isdigit(ch)){
            digCount = 0;

            while(isdigit(ch)){

                //To insert the digit to the string array
                lexeme[strlen(lexeme)] = ch;
                lexeme[strlen(lexeme) + 1] = '\0';
                digCount++;


                //Error check for dig length
                if(digCount > MAX_DIGITS){
                    printf("ERROR! Digits can't have more than 5 characters!");
                    exit(0);
                }

                ch = getc(ifp);

                //Another error check if the token starts with a number then followed by a letter
                if(isalpha(ch)){
                    printf("ERROR! Identifiers can't start with a number!");
                    exit(0);
                }


            }



            //This is to go back 1 step because the loop went to the next ch
            ungetc(ch, ifp);

            //test print
            //printf("numsym: %s\n", lexeme);

            digBuffer = atoi(lexeme);

            addToLinkList(&rootToken, lexeme, digBuffer, numbersym);



        }

        //If not a numsym
        else{
            ungetc(ch, ifp);
        }


        ch = getc(ifp);

        switch(ch){
            case '+':
                //printf("+\n");
                addToLinkList(&rootToken, "+", 0, plussym);
                break;
            case '-':
                //printf("-\n");
                addToLinkList(&rootToken, "-", 0, minussym);
                break;
            case '*':
                //printf("*\n");
                addToLinkList(&rootToken, "*", 0, multsym);
                break;
            case '/':
                //printf("/\n");
                addToLinkList(&rootToken, "/", 0, slashsym);
                break;
            case '(':
                //printf("(\n");
                addToLinkList(&rootToken, "(", 0, lparentsym);
                break;
            case ')':
                //printf(")\n");
                addToLinkList(&rootToken, ")", 0, rparentsym);
                break;
            case '=':
                //printf("=\n");
                addToLinkList(&rootToken, "=", 0, equalsym);
                break;
            case ',':
                //printf(",\n");
                addToLinkList(&rootToken, ",", 0, commasym);
                break;
            case '.':
                //printf(".\n");
                addToLinkList(&rootToken, ".", 0, periodsym);
                break;
            case '<':
                ch = getc(ifp);
                if(ch == '='){
                    //printf("<=\n");
                    addToLinkList(&rootToken, "<=", 0, leqsym);
                }
                else if(ch == '>'){
                    //printf("<>\n");
                    addToLinkList(&rootToken, "<>", 0, neqsym);
                }
                else{
                    //printf("<\n");
                    addToLinkList(&rootToken, "<", 0, lessym);
                    ungetc(ch, ifp);
                }
                break;
            case '>':
                ch = getc(ifp);
                if(ch == '='){
                    //printf(">=\n");
                    addToLinkList(&rootToken, ">=", 0, geqsym);
                }
                else{
                    //printf(">\n");
                    addToLinkList(&rootToken, ">", 0, gtrsym);
                    ungetc(ch, ifp);
                }
                break;
            case ';':
                //printf(";\n");
                addToLinkList(&rootToken, ";", 0, semicolonsym);
                break;
            case ':':
                ch = getc(ifp);
                if(ch == '='){
                    //printf(":=\n");
                    addToLinkList(&rootToken, ":=", 0, becomesym);
                }
                else{
                    ungetc(ch, ifp);
                }
                break;
            default:
                if(isspace(ch) || feof(ifp))
                    break;
                else{
                    printf("Invalid Character %c\n", ch);
                    exit(0);
                }

        }



    }



}

token_type getReserve(char * lexeme){

    char* reserved[] = {"begin", "end", "if", "then", "while",
        "do", "call", "const", "var", "procedure", "write",
        "read", "else", "odd"};
    token_type type;

    int i;

    for(i = 0; i < 14; i++){
        if(strcmp(reserved[i], lexeme) == 0)
            break;
    }

    //odd case
    if (i == 13){
        type = 8;
    }
    else if (i == 14){
        type = 2;
    }
    else{
        type = 21 + i;
    }

    //test print
    //printf("Type: %d\n", type);

    return type;


}

void addToLinkList(token **rootToken, char *lexeme, int value, int type){

    if ((*rootToken)->type == -1){
        strcpy((*rootToken)->lexeme, lexeme);
        (*rootToken)->type = type;
        (*rootToken)->value = value;
    }
    else{
        token *nextToken = malloc(sizeof(token));
        strcpy(nextToken->lexeme,lexeme);
        nextToken->type = type;
        nextToken->value = value;
        (*rootToken)->next = nextToken;
        *rootToken = (*rootToken)->next;
    }



}

void printTableList(token* rootToken, char* tableOutput, char* listOutput){

    FILE *tofp = fopen(tableOutput, "w");
    FILE *lofp = fopen(listOutput, "w");

    token *temp = NULL;

    temp = rootToken->next;

    if (temp == NULL){
        return;
    }

    fprintf(tofp, "lexeme\ttoken-type\n");


    //loop to traverse the linked list
    while(temp != NULL){

        //printing to lexeme table
        fprintf(tofp, "%s\t%d\n", temp->lexeme, temp->type);

        //printing to lexeme list

        //if identsym
        if(temp->type == 2)
            fprintf(lofp, "%d %s ", temp->type, temp->lexeme);
        //if numsym
        else if(temp->type == 3)
            fprintf(lofp, "%d %d ", temp->type, temp->value);
        //if not identsym or numsym
        else
            fprintf(lofp, "%d ", temp->type);


        temp = temp->next;
    }


}







