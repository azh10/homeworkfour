==============
= TO COMPILE =
==============

"gcc virtualmachine.c -o virtualmachine"
"gcc lexer.c -o lexer"
"gcc parser.c -o parser"

==============
=   TO RUN   =
==============

"./lexer"
"./parser" OR "./parser -l"  *the l shows the lexemelist.txt information*
"./virtualmachine"


*the lexer must run before the parser (to produce the lexemelist.txt)

*the virtualmachine reads mcode.txt
